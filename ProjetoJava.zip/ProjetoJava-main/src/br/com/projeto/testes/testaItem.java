package br.com.projeto.testes;

import br.com.projeto.classes.Item;

public class testaItem {
    public static void main(String[] args) {
        Item item = new Item("Abcty5ty","abcdehuihi","insumo",0,13.52f);



    }
}
