package br.com.projeto.classes;

public class Administrador extends Usuario{
    Usuario usuario;
    public Administrador(String login, String senha, boolean statususuario, Setor setor) {
        super(login, senha, statususuario, setor);
    }

    private Usuario novoUsuario(){

        return null;
    }
    private Usuario excluiUsuario(){

        return null;
    }

    private Usuario statusUsuario(){

        return null;
    }

    private Item alteraItens(){

        return null;
    }

}
