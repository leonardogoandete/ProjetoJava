
package br.com.projeto.negocio;

import br.com.projeto.classes.Item;
import br.com.projeto.classes.Solicitacao;

public class Servico {

    public void solicitaItens(){

    }

    public Item consultaItens(){

        return null;
    }

    public Solicitacao verificaStatusSolicitacao(){
        return null;
    }

}
