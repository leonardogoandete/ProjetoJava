package br.com.projeto.classes;



public class itemSolicitado {
    public Solicitacao solicitacao;
    public Item item;


}
